from bingX.standard.standard import Standard
